@SuppressWarnings("serial")
public class DBAppException extends Exception{
	
	 public DBAppException() {
	 }
	
	public DBAppException(String msg) {
		System.out.println( msg );
	}
}
 class CannotCreateTableException extends DBAppException{
	 
	 public CannotCreateTableException() {
	 }
	 
	public CannotCreateTableException(String msg) {
		System.out.println( msg );
	}
}
 
 class InvalidInputException extends DBAppException{
	 
	 public InvalidInputException() {
		 
	 }
	 
	public InvalidInputException(String msg) {
		System.out.println( msg );
	}
}
 
 class FailedtoInsertException extends DBAppException{
	 
	 public FailedtoInsertException() {
		 
	 }
	 
	public FailedtoInsertException(String msg) {
		System.out.println( msg );
	}
}
 
 
 